# WebSetu - AI-Powered Website Builder

A comprehensive AI-powered business website featuring 12 digital services, real-time chat, and modern design.

## Features

- 🌐 **Website Creation** - Professional responsive websites (₹499)
- 🎥 **AI Video Editing** - Advanced video editing with AI tools (₹299)
- 📄 **Resume Builder** - AI-crafted professional resumes (₹199)
- 💬 **WhatsApp Bot** - Automated customer service bots (₹399)
- ✍️ **Content Writing** - SEO-optimized content (₹149)
- 📸 **Photo Editing** - Professional photo enhancement (₹99)
- 🎯 **Portfolio Building** - Stunning portfolio websites (₹399)
- 📈 **SEO Optimization** - Boost your online visibility (₹299)
- 🎨 **UI/UX Development** - Modern interface design (₹599)
- 🖼️ **Thumbnails Design** - Eye-catching thumbnails (₹49)
- 📱 **Social Media Kit** - Complete branding package (₹199)
- 💼 **Business Branding** - Logo and brand identity (₹399)

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Node.js, Express.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Payments**: Stripe integration
- **Real-time**: WebSocket chat system
- **UI Components**: Radix UI with shadcn/ui

## Quick Start

1. **Development**:
   ```bash
   npm run dev
   ```

2. **Build for Production**:
   ```bash
   npm run build
   ```

3. **Database Setup**:
   ```bash
   npm run db:push
   ```

## Deployment

### Vercel Deployment (Recommended)

1. Connect your GitHub repository to Vercel
2. Set environment variables:
   - `DATABASE_URL`
   - `STRIPE_SECRET_KEY`
   - `VITE_STRIPE_PUBLIC_KEY`
3. Deploy automatically

### Other Platforms

- **Netlify**: Use `npm run build` command
- **Railway**: Connect database and deploy
- **Render**: Set build command to `npm run build`

## Environment Variables

```env
DATABASE_URL=your_postgresql_connection_string
STRIPE_SECRET_KEY=sk_your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=pk_your_stripe_public_key
```

## Contact

- **LinkedIn**: [Adarsh Mishra](https://www.linkedin.com/in/adarsh-mishra-7july2003)
- **YouTube**: [@websetu](https://youtube.com/@websetu)
- **Phone**: +91-6307737501
- **Email**: contact@websetu.com

---

Built with 💙 by Adarsh | © 2025 WebSetu. All rights reserved.