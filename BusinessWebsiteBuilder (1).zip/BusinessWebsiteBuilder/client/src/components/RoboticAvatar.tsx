import { useState, useEffect } from "react";

interface RoboticAvatarProps {
  size?: number;
  isActive?: boolean;
}

export default function RoboticAvatar({ size = 40, isActive = false }: RoboticAvatarProps) {
  const [blinkState, setBlinkState] = useState(false);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinkState(true);
      setTimeout(() => setBlinkState(false), 150);
    }, 2000 + Math.random() * 1000); // Random blink between 2-3 seconds

    return () => clearInterval(blinkInterval);
  }, []);

  return (
    <div className={`relative ${isActive ? 'animate-float' : ''}`} style={{ width: size, height: size }}>
      <svg 
        viewBox="0 0 80 80" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg" 
        className="w-full h-full drop-shadow-lg"
      >
        {/* Robot Head */}
        <rect 
          x="15" 
          y="20" 
          width="50" 
          height="45" 
          rx="8" 
          fill="url(#robotGradient)" 
          stroke="#0ea5e9" 
          strokeWidth="2"
        />
        
        {/* Antenna */}
        <line x1="40" y1="20" x2="40" y2="10" stroke="#06b6d4" strokeWidth="2" strokeLinecap="round" />
        <circle cx="40" cy="8" r="3" fill="#06b6d4" className="animate-pulse" />
        
        {/* Eyes */}
        <circle cx="28" cy="35" r="6" fill="#1e293b" />
        <circle cx="52" cy="35" r="6" fill="#1e293b" />
        
        {/* Eye Lights */}
        <circle 
          cx="28" 
          cy="35" 
          r="3" 
          fill={blinkState ? "#1e293b" : "#0ea5e9"} 
          className="transition-all duration-150"
        />
        <circle 
          cx="52" 
          cy="35" 
          r="3" 
          fill={blinkState ? "#1e293b" : "#0ea5e9"} 
          className="transition-all duration-150"
        />
        
        {/* Eye Highlights */}
        {!blinkState && (
          <>
            <circle cx="29" cy="33" r="1" fill="#ffffff" />
            <circle cx="53" cy="33" r="1" fill="#ffffff" />
          </>
        )}
        
        {/* Mouth */}
        <rect x="32" y="48" width="16" height="4" rx="2" fill="#0ea5e9" />
        <rect x="35" y="50" width="2" height="2" fill="#06b6d4" />
        <rect x="39" y="50" width="2" height="2" fill="#06b6d4" />
        <rect x="43" y="50" width="2" height="2" fill="#06b6d4" />
        
        {/* Circuit Pattern */}
        <path 
          d="M20 55L25 55L25 58L30 58M50 55L55 55L55 58L60 58" 
          stroke="#06b6d4" 
          strokeWidth="1.5" 
          strokeLinecap="round"
          opacity="0.8"
        />
        
        {/* Status Indicator */}
        <circle cx="58" cy="28" r="2" fill={isActive ? "#10b981" : "#6b7280"} className="animate-pulse" />
        
        {/* Gradient Definition */}
        <defs>
          <linearGradient id="robotGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="50%" stopColor="#475569" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Glow Effect */}
      {isActive && (
        <div className="absolute inset-0 rounded-full bg-glow-blue/20 blur-md animate-pulse" />
      )}
    </div>
  );
}