import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Bot, User, Minimize2, Maximize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface RealtimeChatProps {
  isOpen: boolean;
  onToggle: () => void;
}

export default function RealtimeChat({ isOpen, onToggle }: RealtimeChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your AI assistant. How can I help you with WebSetu services today?',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      // Initialize WebSocket connection for real-time features
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          console.log('WebSocket connected');
        };

        ws.onmessage = (event) => {
          const data = JSON.parse(event.data);
          if (data.type === 'ai_response') {
            setMessages(prev => [...prev, {
              id: Date.now().toString(),
              content: data.message,
              sender: 'ai',
              timestamp: new Date()
            }]);
            setIsTyping(false);
          }
        };

        ws.onclose = () => {
          console.log('WebSocket disconnected');
        };

        return () => {
          ws.close();
        };
      } catch (error) {
        console.log('WebSocket not available, using fallback');
      }
    }
  }, [isOpen]);

  const generateAIResponse = (userMessage: string): string => {
    const responses = {
      pricing: "Our services start from ₹499 for AI-powered websites. We offer Website Creation (₹499), AI Video Editing (₹299), Resume Builder (₹199), and WhatsApp Bot (₹399).",
      website: "We create professional, responsive websites using AI technology. The process takes 24-48 hours and includes hosting, SSL, and mobile optimization.",
      services: "WebSetu offers 4 main services: 🌐 Website Creation, 🎥 AI Video Editing, 📄 Resume Builder, and 💬 WhatsApp Bot integration. All powered by AI!",
      payment: "We accept payments via Stripe (cards, UPI, net banking). All transactions are secure and encrypted. You'll receive a confirmation email after payment.",
      contact: "You can reach us at +91-6307737501 or connect with Adarsh on LinkedIn. We respond within 2-4 hours during business hours.",
      default: "I'd be happy to help! You can ask me about our services, pricing, website creation process, or any other questions about WebSetu."
    };

    const message = userMessage.toLowerCase();
    if (message.includes('price') || message.includes('cost') || message.includes('₹')) {
      return responses.pricing;
    } else if (message.includes('website') || message.includes('site')) {
      return responses.website;
    } else if (message.includes('service')) {
      return responses.services;
    } else if (message.includes('payment') || message.includes('pay')) {
      return responses.payment;
    } else if (message.includes('contact') || message.includes('phone') || message.includes('call')) {
      return responses.contact;
    } else {
      return responses.default;
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Send via WebSocket if available
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'user_message',
        message: inputMessage
      }));
    } else {
      // Fallback: simulate AI response
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          content: generateAIResponse(inputMessage),
          sender: 'ai',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiResponse]);
        setIsTyping(false);
      }, 1500);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        className="fixed bottom-6 right-6 w-16 h-16 rounded-full bg-gradient-to-r from-glow-blue to-glow-cyan silver-glow ai-pulse z-50"
      >
        <Bot className="w-8 h-8" />
      </Button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 20 }}
        className="fixed bottom-6 right-6 w-96 h-[500px] z-50"
      >
        <Card className="bg-dark-card silver-glow h-full flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg metallic-text flex items-center gap-2">
              <Bot className="w-5 h-5 text-glow-blue animate-pulse" />
              AI Assistant
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggle}
              className="h-8 w-8 p-0"
            >
              <Minimize2 className="w-4 h-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-4">
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-2 ${
                      message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.sender === 'ai' 
                        ? 'bg-glow-blue/20 text-glow-blue' 
                        : 'bg-silver/20 text-silver'
                    }`}>
                      {message.sender === 'ai' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>
                    <div
                      className={`max-w-[70%] p-3 rounded-lg ${
                        message.sender === 'user'
                          ? 'bg-glow-blue/20 text-white ml-auto'
                          : 'bg-dark-base text-silver-light'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                      <span className="text-xs opacity-60 mt-1 block">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex items-start gap-2">
                    <div className="w-8 h-8 rounded-full bg-glow-blue/20 text-glow-blue flex items-center justify-center">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-dark-base text-silver-light p-3 rounded-lg">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-glow-blue rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-glow-blue rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-glow-blue rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="flex gap-2 mt-4">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="bg-dark-base border-silver/30 text-white placeholder-silver/60"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim()}
                className="bg-gradient-to-r from-glow-blue to-glow-cyan"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}