import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import ParticleBackground from "./ParticleBackground";
import RealtimeChat from "./RealtimeChat";
import WebSetuLogo from "./Logo";

const navigation = [
  { name: "Home", href: "#hero" },
  { name: "Services", href: "#services" },
  { name: "About", href: "#about" },
  { name: "Portfolio", href: "#portfolio" },
  { name: "Pricing", href: "#pricing" },
  { name: "Testimonials", href: "#testimonials" },
  { name: "Contact", href: "#contact" },
  { name: "FAQ", href: "#faq" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <div className="min-h-screen bg-dark-base text-white relative">
      <ParticleBackground />
      
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'github-style-nav' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <Link href="/">
                <div className="cursor-pointer">
                  <WebSetuLogo className="w-10 h-10" textClassName="text-2xl" />
                </div>
              </Link>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                {navigation.map((item) => (
                  <a key={item.name} href={item.href} className="nav-link cursor-pointer transition-colors duration-300 text-white hover:text-glow-cyan">
                    {item.name}
                  </a>
                ))}
              </div>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white hover:text-glow-cyan"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-dark-card border-t border-glow-blue/20">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigation.map((item) => (
                <a key={item.name} href={item.href} className="block px-3 py-2 cursor-pointer transition-colors duration-300 text-white hover:text-glow-cyan">
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="relative z-10 pt-16">
        {children}
      </main>

      {/* Footer */}
      <footer className="section-bg py-12 border-t border-glow-blue/20 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="col-span-1 md:col-span-2">
              <WebSetuLogo className="w-12 h-12" textClassName="text-2xl" />
              <p className="text-gray-300 mb-6 max-w-md">
                Empowering businesses worldwide with AI-powered digital solutions. Professional websites, automation, and digital services at affordable prices.
              </p>
              <div className="flex space-x-4">
                <a href="https://www.linkedin.com/in/adarsh-mishra-7july2003" target="_blank" rel="noopener noreferrer" className="text-glow-blue hover:text-glow-cyan transition-colors duration-300" title="Connect on LinkedIn">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                </a>
                <a href="https://youtube.com/@websetu" target="_blank" rel="noopener noreferrer" className="text-glow-blue hover:text-glow-cyan transition-colors duration-300" title="Subscribe on YouTube">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                  </svg>
                </a>
                <a href="tel:+916307737501" className="text-glow-blue hover:text-glow-cyan transition-colors duration-300" title="Call us">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                  </svg>
                </a>
                <a href="mailto:contact@websetu.com" className="text-glow-blue hover:text-glow-cyan transition-colors duration-300" title="Email us">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.89 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                  </svg>
                </a>
              </div>
            </div>
            
            {/* Services */}
            <div>
              <h4 className="font-poppins text-lg font-semibold mb-4 text-glow-cyan">Services</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/services">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">Website Creation</span>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">AI Video Editing</span>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">Resume Builder</span>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">WhatsApp Bot</span>
                  </Link>
                </li>
              </ul>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="font-poppins text-lg font-semibold mb-4 text-glow-cyan">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">About Us</span>
                  </Link>
                </li>
                <li>
                  <Link href="/portfolio">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">Portfolio</span>
                  </Link>
                </li>
                <li>
                  <Link href="/pricing">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">Pricing</span>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <span className="text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer">Contact</span>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          
          <hr className="border-gray-600 my-8" />
          
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 mb-4 md:mb-0">© 2025 WebSetu. All rights reserved.</p>
            <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4">
              <p className="text-glow-cyan font-semibold">Made with 💙 by Adarsh</p>
              <div className="flex space-x-4">
                <a href="https://www.linkedin.com/in/adarsh-mishra-7july2003" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-300 hover:text-glow-cyan transition-colors">
                  LinkedIn
                </a>
                <a href="https://youtube.com/@websetu" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-300 hover:text-glow-cyan transition-colors">
                  YouTube
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <RealtimeChat isOpen={chatOpen} onToggle={() => setChatOpen(!chatOpen)} />
    </div>
  );
}
