import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { MessageCircle, X, Send, Bot } from "lucide-react";
import RoboticAvatar from "./RoboticAvatar";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi! I'm your AI assistant. I can help you with:\n• Service information\n• Pricing details\n• Project timeline\n• Technical support\n\nHow can I help you today?",
      isUser: false,
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");

  const getBotResponse = (userMessage: string) => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('price') || message.includes('cost') || message.includes('pricing')) {
      return "Our pricing starts from ₹499 for the Starter plan, ₹999 for Pro, and ₹1999 for Agency. Each plan includes different features and services. Would you like me to explain a specific plan?";
    } else if (message.includes('website') || message.includes('site')) {
      return "We create professional AI-powered websites for portfolios, e-commerce stores, and businesses. Delivery is typically 24-48 hours. What type of website do you need?";
    } else if (message.includes('time') || message.includes('delivery') || message.includes('fast')) {
      return "Most websites are delivered within 24-48 hours! Complex projects like e-commerce stores may take 2-3 days. Our AI automation helps us work super fast.";
    } else if (message.includes('whatsapp') || message.includes('bot')) {
      return "Yes! We create WhatsApp bots for automated customer service starting from ₹399. They can handle common queries, bookings, and more. Perfect for Indian businesses!";
    } else if (message.includes('payment') || message.includes('pay')) {
      return "We accept UPI, bank transfers, cards, and PayPal. Payment is typically 50% advance, 50% on delivery. Very secure and convenient!";
    } else if (message.includes('support') || message.includes('help')) {
      return "We provide 24/7 support and free minor updates for 30 days after delivery. You can reach us via email at support@websetu.in or call us at +91-6307737501!";
    } else if (message.includes('contact') || message.includes('phone') || message.includes('call')) {
      return "You can reach us at +91-6307737501 or email support@websetu.in. Connect with founder Adarsh on LinkedIn: https://www.linkedin.com/in/adarsh-mishra-7july2003";
    } else if (message.includes('founder') || message.includes('adarsh')) {
      return "Our founder Adarsh Mishra is a passionate technologist who started WebSetu to make AI-powered digital solutions accessible to every Indian business. Connect with him on LinkedIn!";
    } else {
      return "I'm your AI assistant! 🤖 Ask me about our services, pricing, delivery time, or contact info. How can I help you today?";
    }
  };

  const sendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");

    // Simulate bot response after a delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(inputValue),
        isUser: false,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Button with Robotic Avatar */}
      <div className="relative">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-slate-700 to-slate-600 hover:scale-110 transform transition-all duration-300 animate-float glow-border shadow-2xl p-1"
          size="icon"
        >
          {isOpen ? (
            <X className="h-6 w-6 text-white" />
          ) : (
            <RoboticAvatar size={48} isActive={true} />
          )}
        </Button>
        
        {/* Status Indicator */}
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-dark-base animate-pulse">
          <div className="w-full h-full bg-green-400 rounded-full animate-ping opacity-75"></div>
        </div>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <Card className="absolute bottom-16 right-0 w-80 h-96 bg-dark-card border-glow-blue/30 glow-border overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-glow-blue to-glow-cyan p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <RoboticAvatar size={32} isActive={true} />
                <div>
                  <h4 className="font-poppins font-semibold text-white">WebSetu AI Assistant</h4>
                  <p className="text-sm text-blue-100">🟢 Online now</p>
                </div>
              </div>
              <Button
                onClick={() => setIsOpen(false)}
                variant="ghost"
                size="icon"
                className="text-white hover:text-gray-200 h-6 w-6"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-0 flex flex-col h-full">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-64">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs p-3 rounded-lg ${
                      message.isUser
                        ? 'bg-glow-blue text-white ml-auto'
                        : 'bg-glow-blue/20 text-gray-200'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-600">
              <div className="flex space-x-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1 bg-dark-base border-gray-600 focus:border-glow-blue text-white"
                />
                <Button
                  onClick={sendMessage}
                  size="icon"
                  className="bg-glow-blue hover:bg-glow-cyan transition-colors duration-300"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
