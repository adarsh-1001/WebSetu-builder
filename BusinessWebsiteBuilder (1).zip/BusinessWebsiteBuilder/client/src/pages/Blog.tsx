import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, ArrowRight } from "lucide-react";

export default function Blog() {
  const blogPosts = [
    {
      title: "Why Your Business Needs a Website in 2025",
      excerpt: "Discover how having a professional website can transform your business and reach new customers in the digital age. Learn about the latest trends and technologies that are shaping the future of online presence.",
      image: "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Business Growth",
      date: "Jan 15, 2025",
      readTime: "5 min read",
      featured: true
    },
    {
      title: "How AI is Revolutionizing Web Development",
      excerpt: "Explore the latest AI technologies that are making website creation faster, smarter, and more accessible than ever before. From automated design to intelligent content generation.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "AI Technology",
      date: "Jan 12, 2025",
      readTime: "7 min read",
      featured: true
    },
    {
      title: "Digital Transformation for Indian SMEs",
      excerpt: "A comprehensive guide to help small and medium enterprises in India embrace digital transformation affordably and effectively in today's competitive market.",
      image: "https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Small Business",
      date: "Jan 10, 2025",
      readTime: "6 min read",
      featured: true
    },
    {
      title: "The Future of E-commerce in India",
      excerpt: "Understanding the evolving landscape of online retail in India and how AI is changing customer experiences and business operations.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "E-commerce",
      date: "Jan 8, 2025",
      readTime: "8 min read",
      featured: false
    },
    {
      title: "Building Trust in Digital Business",
      excerpt: "Essential strategies for establishing credibility and trust with your online customers through design, security, and customer service.",
      image: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Digital Marketing",
      date: "Jan 5, 2025",
      readTime: "4 min read",
      featured: false
    },
    {
      title: "WhatsApp Business API: A Game Changer",
      excerpt: "How WhatsApp Business API and automated bots are transforming customer communication and support for Indian businesses.",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Automation",
      date: "Jan 3, 2025",
      readTime: "5 min read",
      featured: false
    }
  ];

  const featuredPosts = blogPosts.filter(post => post.featured);
  const regularPosts = blogPosts.filter(post => !post.featured);

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Latest Blog Posts</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Insights, tips, and trends in AI-powered digital solutions
          </p>
        </div>

        {/* Featured Posts */}
        <div className="mb-16">
          <h2 className="font-poppins text-2xl font-bold mb-8 text-glow-cyan">Featured Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredPosts.map((post, index) => (
              <article key={index} className="group cursor-pointer">
                <Card className="bg-dark-card glow-border hover:glow-border transition-all duration-300 overflow-hidden">
                  <div className="relative overflow-hidden">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transform transition-all duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-glow-blue text-white">
                        {post.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="flex items-center text-sm text-gray-400 mb-3">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{post.date}</span>
                      <span className="mx-2">•</span>
                      <span>{post.readTime}</span>
                    </div>
                    
                    <h3 className="font-poppins text-xl font-bold mb-3 group-hover:text-glow-blue transition-colors duration-300">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-300 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    
                    <Button variant="ghost" className="p-0 text-glow-cyan hover:text-glow-blue transition-colors duration-300">
                      Read More <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </article>
            ))}
          </div>
        </div>

        {/* Regular Posts */}
        <div>
          <h2 className="font-poppins text-2xl font-bold mb-8 text-glow-cyan">More Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {regularPosts.map((post, index) => (
              <article key={index} className="group cursor-pointer">
                <Card className="bg-dark-card border border-gray-600 hover:border-glow-blue hover:glow-border transition-all duration-300 overflow-hidden">
                  <div className="md:flex">
                    <div className="md:w-1/3 relative overflow-hidden">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-48 md:h-full object-cover group-hover:scale-105 transform transition-all duration-500"
                      />
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-glow-blue text-white text-xs">
                          {post.category}
                        </Badge>
                      </div>
                    </div>
                    
                    <CardContent className="md:w-2/3 p-6">
                      <div className="flex items-center text-sm text-gray-400 mb-3">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{post.date}</span>
                        <span className="mx-2">•</span>
                        <span>{post.readTime}</span>
                      </div>
                      
                      <h3 className="font-poppins text-lg font-bold mb-3 group-hover:text-glow-blue transition-colors duration-300">
                        {post.title}
                      </h3>
                      
                      <p className="text-gray-300 mb-4 text-sm">
                        {post.excerpt.substring(0, 120)}...
                      </p>
                      
                      <Button variant="ghost" className="p-0 text-glow-cyan hover:text-glow-blue transition-colors duration-300">
                        Read More <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </div>
                </Card>
              </article>
            ))}
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-20">
          <Card className="bg-dark-card glow-border max-w-4xl mx-auto">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-glow-blue">Stay Updated</h3>
              <p className="text-gray-300 text-lg mb-6">
                Subscribe to our newsletter and get the latest insights about AI, web development, and digital transformation delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="flex-1 px-4 py-3 bg-dark-base border border-gray-600 rounded-lg focus:border-glow-blue focus:ring-1 focus:ring-glow-blue outline-none transition-colors duration-300"
                />
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-6 py-3 font-poppins font-semibold">
                  Subscribe
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
