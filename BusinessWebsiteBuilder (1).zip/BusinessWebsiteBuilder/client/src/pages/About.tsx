import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

export default function About() {
  return (
    <section className="section-bg py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">About WebSetu</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Founded by Adarsh, WebSetu is revolutionizing how Indian businesses establish their digital presence with AI-powered solutions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Modern tech startup office in India" 
              className="rounded-xl shadow-2xl w-full h-auto glow-border"
            />
          </div>
          
          <div className="space-y-8">
            <div>
              <h3 className="font-poppins text-2xl font-semibold mb-4 text-glow-cyan">Our Mission</h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                To democratize digital presence for every Indian business, making professional websites and AI-powered services accessible and affordable for all.
              </p>
            </div>
            
            <div>
              <h3 className="font-poppins text-2xl font-semibold mb-4 text-glow-cyan">Why We're Different</h3>
              <div className="space-y-4">
                {[
                  {
                    title: "AI-Driven Solutions",
                    desc: "Leveraging cutting-edge AI to automate website creation and digital marketing"
                  },
                  {
                    title: "No Coding Needed",
                    desc: "Simple process that anyone can understand and use"
                  },
                  {
                    title: "Lightning Fast Delivery",
                    desc: "Get your website live within 24-48 hours"
                  },
                  {
                    title: "Made for India",
                    desc: "Understanding local business needs and culture"
                  }
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <CheckCircle className="text-emerald-400 h-6 w-6 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-lg">{item.title}</h4>
                      <p className="text-gray-300">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-20">
          <Card className="bg-dark-card glow-border">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-glow-blue">Meet the Founder</h3>
              <div className="max-w-3xl mx-auto">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" 
                  alt="Adarsh - Founder of WebSetu" 
                  className="w-32 h-32 rounded-full mx-auto mb-6 glow-border"
                />
                <h4 className="font-poppins text-xl font-semibold mb-2 text-glow-cyan">Adarsh</h4>
                <p className="text-gray-300 text-lg leading-relaxed">
                  A passionate technologist and entrepreneur with a vision to make digital transformation accessible to every Indian business. 
                  With expertise in AI and web development, Adarsh founded WebSetu to bridge the gap between advanced technology and small business needs.
                </p>
                <div className="mt-4 flex flex-col sm:flex-row gap-4 justify-center">
                  <a href="https://www.linkedin.com/in/adarsh-mishra-7july2003" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-blue-600 hover:bg-blue-700 font-semibold transition-colors duration-300">
                      Connect on LinkedIn
                    </Button>
                  </a>
                  <a href="tel:+916307737501">
                    <Button variant="outline" className="border-glow-blue hover:bg-glow-blue/10 font-semibold transition-colors duration-300">
                      Call: +91-6307737501
                    </Button>
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
