import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  Zap, IndianRupee, Bot, ChevronDown, Sparkles, Cpu, Layers3, 
  Star, Users, Award, CheckCircle, Phone, Mail, MapPin, 
  Globe, Video, FileText, MessageSquare 
} from "lucide-react";

export default function Home() {
  const scrollToServices = () => {
    const element = document.getElementById("services-preview");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section id="hero" className="hero-bg min-h-screen flex items-center relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <h1 className="font-poppins text-4xl md:text-6xl lg:text-7xl font-bold mb-8 metallic-text">
              Professional AI-Powered Digital Solutions
            </h1>
            <div className="flex justify-center mb-6">
              <div className="relative bg-silver/10 rounded-full p-4">
                <Cpu className="w-16 h-16 text-glow-blue" />
              </div>
            </div>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto">
              Transform your business with cutting-edge AI technology. Get professional websites, automation, and digital solutions at unbeatable prices.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Link href="/checkout">
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-4 text-lg font-poppins font-semibold hover:opacity-90 transition-opacity duration-300">
                  Get Started for ₹499
                </Button>
              </Link>
              <Link href="/services">
                <Button variant="outline" className="border-2 border-silver px-8 py-4 text-lg font-poppins font-semibold text-silver-light hover:bg-silver/10 transition-colors duration-300">
                  View Services
                </Button>
              </Link>
            </div>
            
            {/* Feature highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <Card className="bg-dark-card border border-silver/30 hover:border-silver/60 transition-colors">
                <CardContent className="p-6 text-center">
                  <Zap className="h-12 w-12 text-glow-blue mb-4 mx-auto" />
                  <h3 className="font-poppins text-xl font-semibold mb-2 text-white">Lightning Fast</h3>
                  <p className="text-silver-light">Get your website delivered in 24-48 hours with AI automation</p>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-silver/60 transition-colors">
                <CardContent className="p-6 text-center">
                  <IndianRupee className="h-12 w-12 text-silver mb-4 mx-auto" />
                  <h3 className="font-poppins text-xl font-semibold mb-2 text-white">Affordable</h3>
                  <p className="text-silver-light">Starting from just ₹499 - perfect for all businesses</p>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-silver/60 transition-colors">
                <CardContent className="p-6 text-center">
                  <Bot className="h-12 w-12 text-emerald-400 mb-4 mx-auto" />
                  <h3 className="font-poppins text-xl font-semibold mb-2 text-white">AI Automation</h3>
                  <p className="text-silver-light">No coding needed - AI handles everything for you</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="mt-12">
              <button 
                onClick={scrollToServices}
                className="inline-block animate-bounce text-glow-blue hover:text-glow-cyan transition-colors duration-300"
              >
                <ChevronDown className="h-8 w-8" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-white">Our Comprehensive Services</h2>
            <p className="text-xl text-silver-light max-w-3xl mx-auto">Complete digital solutions for your business needs - from websites to content creation</p>
          </div>
          
          {/* Core Services */}
          <div className="mb-16">
            <h3 className="font-poppins text-2xl font-bold mb-8 text-center text-glow-blue">Core Services</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <Globe className="h-12 w-12 text-glow-blue mb-4 mx-auto" />
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Website Creation</h4>
                  <p className="text-silver-light text-sm mb-4">Professional responsive websites with modern design and functionality</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹499</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <Video className="h-12 w-12 text-glow-blue mb-4 mx-auto" />
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">AI Video Editing</h4>
                  <p className="text-silver-light text-sm mb-4">Professional video editing with advanced AI tools and effects</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹299</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <FileText className="h-12 w-12 text-glow-blue mb-4 mx-auto" />
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Resume Builder</h4>
                  <p className="text-silver-light text-sm mb-4">AI-crafted professional resumes that get you hired</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹199</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <MessageSquare className="h-12 w-12 text-glow-blue mb-4 mx-auto" />
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">WhatsApp Bot</h4>
                  <p className="text-silver-light text-sm mb-4">Automated customer service and marketing bots</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹399</div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Extended Services */}
          <div className="mb-16">
            <h3 className="font-poppins text-2xl font-bold mb-8 text-center text-glow-blue">Extended Services</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">✍️</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Content Writing</h4>
                  <p className="text-silver-light text-sm mb-4">SEO-optimized blogs, articles, and web content</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹149</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">📸</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Photo Editing</h4>
                  <p className="text-silver-light text-sm mb-4">Professional photo editing and enhancement</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹99</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">🎯</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Portfolio Building</h4>
                  <p className="text-silver-light text-sm mb-4">Stunning portfolios that showcase your work professionally</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹399</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">📈</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">SEO Optimization</h4>
                  <p className="text-silver-light text-sm mb-4">Boost your website ranking and online visibility</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹299</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">🎨</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">UI/UX Development</h4>
                  <p className="text-silver-light text-sm mb-4">Modern, user-friendly interface design</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹599</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">🖼️</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Thumbnails Design</h4>
                  <p className="text-silver-light text-sm mb-4">Eye-catching thumbnails for videos and content</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹49</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">📱</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Social Media Kit</h4>
                  <p className="text-silver-light text-sm mb-4">Complete social media branding package</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹199</div>
                </CardContent>
              </Card>
              
              <Card className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">💼</div>
                  <h4 className="font-poppins text-xl font-semibold mb-3 text-white">Business Branding</h4>
                  <p className="text-silver-light text-sm mb-4">Logo design and complete brand identity creation</p>
                  <div className="text-glow-cyan font-semibold">Starting ₹399</div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Premium Add-ons */}
          <div className="mb-12">
            <h3 className="font-poppins text-2xl font-bold mb-8 text-center text-glow-blue">Premium Add-ons</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="bg-gradient-to-br from-dark-card to-dark-base border border-glow-blue/50">
                <CardContent className="p-8 text-center">
                  <div className="text-5xl mb-6">🚀</div>
                  <h4 className="font-poppins text-2xl font-bold mb-4 text-white">Express Delivery</h4>
                  <p className="text-silver-light mb-4">Get your project completed in 12-24 hours</p>
                  <div className="text-glow-cyan font-bold text-xl">+₹200</div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-dark-card to-dark-base border border-glow-blue/50">
                <CardContent className="p-8 text-center">
                  <div className="text-5xl mb-6">🎯</div>
                  <h4 className="font-poppins text-2xl font-bold mb-4 text-white">Premium Support</h4>
                  <p className="text-silver-light mb-4">Priority support and unlimited revisions</p>
                  <div className="text-glow-cyan font-bold text-xl">+₹150</div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-dark-card to-dark-base border border-glow-blue/50">
                <CardContent className="p-8 text-center">
                  <div className="text-5xl mb-6">⚡</div>
                  <h4 className="font-poppins text-2xl font-bold mb-4 text-white">AI Enhancement</h4>
                  <p className="text-silver-light mb-4">Advanced AI features and automation</p>
                  <div className="text-glow-cyan font-bold text-xl">+₹300</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">How We Work</h2>
            <p className="text-xl text-silver-light">Our simple 4-step process to get your project done</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Consultation", desc: "We discuss your requirements and understand your vision", icon: "💬" },
              { step: "02", title: "Design & Plan", desc: "Our AI creates a personalized design and development plan", icon: "🎨" },
              { step: "03", title: "Development", desc: "Our team builds your project using cutting-edge AI technology", icon: "⚡" },
              { step: "04", title: "Delivery", desc: "We deliver your completed project within 24-48 hours", icon: "🚀" }
            ].map((process, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30 relative overflow-hidden">
                <CardContent className="p-8 text-center relative z-10">
                  <div className="text-6xl mb-4">{process.icon}</div>
                  <div className="text-glow-cyan text-lg font-bold mb-2">Step {process.step}</div>
                  <h3 className="font-poppins text-xl font-bold mb-4 text-white">{process.title}</h3>
                  <p className="text-silver-light">{process.desc}</p>
                </CardContent>
                <div className="absolute top-4 right-4 text-6xl font-bold text-silver/10">{process.step}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-poppins text-4xl font-bold mb-6 text-white">About WebSetu</h2>
              <p className="text-silver-light mb-6 text-lg">
                WebSetu is founded by Adarsh, a passionate entrepreneur dedicated to empowering businesses worldwide with affordable AI-powered digital solutions. We believe every business deserves a professional online presence.
              </p>
              <p className="text-silver-light mb-6">
                Our mission is to make professional web services accessible to small and medium businesses globally, using cutting-edge AI technology to deliver quality results at unbeatable prices.
              </p>
              <div className="flex items-center space-x-4">
                <Award className="h-8 w-8 text-glow-blue" />
                <span className="text-white font-semibold">100+ Happy Clients</span>
              </div>
            </div>
            <div className="bg-dark-card p-8 rounded-lg border border-silver/30">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-white">Why Choose Us?</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-400 mr-3" />
                  <span className="text-silver-light">Fast 24-48 hour delivery</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-400 mr-3" />
                  <span className="text-silver-light">Affordable pricing for all businesses</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-400 mr-3" />
                  <span className="text-silver-light">AI-powered professional quality</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-400 mr-3" />
                  <span className="text-silver-light">Ongoing support and maintenance</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Our Portfolio</h2>
            <p className="text-xl text-silver-light">Some of our recent projects</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "E-commerce Store", category: "Online Business", image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
              { title: "Portfolio Website", category: "Personal Brand", image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
              { title: "Restaurant Website", category: "Food Business", image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
            ].map((project, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors overflow-hidden">
                <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${project.image})` }} />
                <CardContent className="p-6">
                  <h3 className="font-poppins text-xl font-semibold mb-2 text-white">{project.title}</h3>
                  <p className="text-glow-blue text-sm">{project.category}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-bg py-16 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: "200+", label: "Projects Completed", icon: "✅" },
              { number: "50+", label: "Happy Clients", icon: "😊" },
              { number: "24hrs", label: "Average Delivery", icon: "⚡" },
              { number: "99%", label: "Client Satisfaction", icon: "⭐" }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl mb-2">{stat.icon}</div>
                <div className="text-3xl md:text-4xl font-bold text-glow-cyan mb-2">{stat.number}</div>
                <div className="text-silver-light">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Technologies We Use</h2>
            <p className="text-xl text-silver-light">Cutting-edge tools and platforms for superior results</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {[
              { name: "React", icon: "⚛️" },
              { name: "AI/ML", icon: "🤖" },
              { name: "Node.js", icon: "🟢" },
              { name: "WordPress", icon: "📝" },
              { name: "Stripe", icon: "💳" },
              { name: "Cloud", icon: "☁️" }
            ].map((tech, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">{tech.icon}</div>
                  <div className="text-white font-semibold">{tech.name}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Simple Pricing</h2>
            <p className="text-xl text-silver-light">Choose the perfect plan for your business</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              { 
                name: "Starter", 
                price: "₹499", 
                features: ["Basic Website", "Mobile Responsive", "Contact Form", "Basic SEO"] 
              },
              { 
                name: "Professional", 
                price: "₹999", 
                features: ["Advanced Website", "E-commerce Ready", "WhatsApp Integration", "Advanced SEO", "Analytics"] 
              },
              { 
                name: "Enterprise", 
                price: "₹1999", 
                features: ["Custom Design", "Advanced Features", "AI Chatbot", "Priority Support", "Monthly Updates"] 
              },
            ].map((plan, index) => (
              <Card key={index} className={`bg-dark-card border ${index === 1 ? 'border-glow-blue' : 'border-silver/30'} relative`}>
                {index === 1 && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-glow-blue text-dark-base px-4 py-2 rounded-full text-sm font-semibold">Popular</span>
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-center">
                    <h3 className="font-poppins text-2xl font-bold text-white mb-2">{plan.name}</h3>
                    <div className="text-4xl font-bold text-glow-cyan">{plan.price}</div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center text-silver-light">
                        <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link href="/checkout">
                    <Button className="w-full bg-gradient-to-r from-glow-blue to-glow-cyan text-white font-semibold py-3">
                      Get Started
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">What Our Clients Say</h2>
            <p className="text-xl text-silver-light">Real feedback from real businesses</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                name: "Raj Patel", 
                business: "Local Restaurant Owner", 
                review: "WebSetu created an amazing website for my restaurant. Orders increased by 40% in just 2 months!",
                rating: 5
              },
              { 
                name: "Priya Sharma", 
                business: "Fashion Designer", 
                review: "Professional portfolio website delivered in just 2 days. Exactly what I needed for my business.",
                rating: 5
              },
              { 
                name: "Amit Kumar", 
                business: "Consultant", 
                review: "Great value for money. The AI chatbot feature really helps with customer queries.",
                rating: 5
              },
            ].map((testimonial, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-silver-light mb-4">"{testimonial.review}"</p>
                  <div>
                    <p className="font-semibold text-white">{testimonial.name}</p>
                    <p className="text-sm text-glow-blue">{testimonial.business}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Get In Touch</h2>
            <p className="text-xl text-silver-light">Ready to transform your business? Let's talk!</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="font-poppins text-2xl font-bold mb-6 text-white">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-glow-blue mr-4" />
                  <div>
                    <p className="text-white font-semibold">Phone</p>
                    <p className="text-silver-light">+91-6307737501</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-glow-blue mr-4" />
                  <div>
                    <p className="text-white font-semibold">Email</p>
                    <p className="text-silver-light">contact@websetu.com</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-6 w-6 text-glow-blue mr-4" />
                  <div>
                    <p className="text-white font-semibold">Location</p>
                    <p className="text-silver-light">India</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h4 className="font-poppins text-xl font-semibold mb-4 text-white">Follow Us</h4>
                <div className="flex space-x-4">
                  <a href="https://www.linkedin.com/in/adarsh-mishra-7july2003" target="_blank" rel="noopener noreferrer" 
                     className="bg-dark-card p-3 rounded-full border border-silver/30 hover:border-glow-blue transition-colors">
                    <svg className="w-5 h-5 text-glow-blue" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            
            <div className="bg-dark-card p-8 rounded-lg border border-silver/30">
              <h3 className="font-poppins text-2xl font-bold mb-6 text-white">Quick Contact</h3>
              <form className="space-y-6">
                <div>
                  <input 
                    type="text" 
                    placeholder="Your Name" 
                    className="w-full p-3 bg-dark-base border border-silver/30 rounded text-white placeholder-silver/60"
                  />
                </div>
                <div>
                  <input 
                    type="email" 
                    placeholder="Your Email" 
                    className="w-full p-3 bg-dark-base border border-silver/30 rounded text-white placeholder-silver/60"
                  />
                </div>
                <div>
                  <textarea 
                    placeholder="Your Message" 
                    rows={4}
                    className="w-full p-3 bg-dark-base border border-silver/30 rounded text-white placeholder-silver/60"
                  ></textarea>
                </div>
                <Button className="w-full bg-gradient-to-r from-glow-blue to-glow-cyan text-white font-semibold py-3">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Industries We Serve */}
      <section className="hero-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Industries We Serve</h2>
            <p className="text-xl text-silver-light">Specialized solutions for diverse business sectors</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { name: "E-commerce", icon: "🛒", desc: "Online stores with payment integration" },
              { name: "Restaurants", icon: "🍕", desc: "Menu displays and online ordering" },
              { name: "Healthcare", icon: "🏥", desc: "Patient portals and appointment systems" },
              { name: "Education", icon: "🎓", desc: "Learning management systems" },
              { name: "Real Estate", icon: "🏠", desc: "Property listings and virtual tours" },
              { name: "Finance", icon: "💰", desc: "Secure financial dashboards" },
              { name: "Technology", icon: "💻", desc: "SaaS platforms and tech solutions" },
              { name: "Consulting", icon: "💼", desc: "Professional service websites" }
            ].map((industry, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30 hover:border-glow-blue transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">{industry.icon}</div>
                  <h3 className="font-poppins text-lg font-semibold mb-2 text-white">{industry.name}</h3>
                  <p className="text-silver-light text-sm">{industry.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="section-bg py-20 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-4xl font-bold mb-6 text-white">Frequently Asked Questions</h2>
            <p className="text-xl text-silver-light">Everything you need to know about our services</p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                question: "How quickly can you deliver my website?",
                answer: "We deliver most websites within 24-48 hours using our AI-powered development process."
              },
              {
                question: "Do I need technical knowledge to use your services?",
                answer: "Not at all! Our AI handles all the technical work. You just need to provide your business information and preferences."
              },
              {
                question: "What's included in the basic website package?",
                answer: "The basic package includes a responsive design, contact forms, basic SEO optimization, and mobile compatibility."
              },
              {
                question: "Do you provide ongoing support?",
                answer: "Yes, we provide ongoing support and maintenance for all our clients to ensure their websites stay updated and secure."
              },
              {
                question: "Can I make changes to my website after delivery?",
                answer: "Absolutely! We provide easy-to-use content management tools and offer update services as needed."
              }
            ].map((faq, index) => (
              <Card key={index} className="bg-dark-card border border-silver/30">
                <CardContent className="p-6">
                  <h3 className="font-poppins text-lg font-semibold mb-3 text-white">{faq.question}</h3>
                  <p className="text-silver-light">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
}
