import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { PortfolioItem } from "@shared/schema";

export default function Portfolio() {
  const { data: portfolioItems, isLoading, error } = useQuery<PortfolioItem[]>({
    queryKey: ['/api/portfolio'],
  });

  if (isLoading) {
    return (
      <section className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-glow-blue mx-auto" />
            <p className="text-gray-300 mt-4">Loading portfolio items...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error || !portfolioItems) {
    return (
      <section className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-red-400">Failed to load portfolio items. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="section-bg py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Our Portfolio</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Showcase of our recent AI-powered website and digital solutions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <div key={item.id} className="group cursor-pointer">
              <Card className="bg-dark-card glow-border hover:glow-border overflow-hidden">
                <div className="relative overflow-hidden">
                  <img 
                    src={item.imageUrl || `https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600`} 
                    alt={item.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transform transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Project
                    </Button>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <div className="mb-2">
                    <span className="text-glow-cyan text-sm font-semibold">{item.category}</span>
                  </div>
                  <h3 className="font-poppins text-xl font-semibold mb-2 group-hover:text-glow-blue transition-colors duration-300">
                    {item.title}
                  </h3>
                  <p className="text-gray-300 mb-4">{item.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {item.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="px-3 py-1 bg-glow-blue/20 text-glow-cyan text-xs rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <Button 
                    className="w-full mt-4 bg-gradient-to-r from-glow-blue to-glow-cyan hover:scale-105 transform transition-all duration-300"
                    onClick={() => item.liveUrl && window.open(item.liveUrl, '_blank')}
                  >
                    View Live Demo
                  </Button>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <Card className="bg-dark-card glow-border max-w-4xl mx-auto">
            <CardContent className="p-8">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-glow-blue">Ready to Build Your Digital Presence?</h3>
              <p className="text-gray-300 text-lg mb-6">
                Join hundreds of satisfied clients who transformed their businesses with WebSetu's AI-powered solutions.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-3 text-lg font-poppins font-semibold">
                  Start Your Project
                </Button>
                <Button variant="outline" className="border-glow-blue px-8 py-3 text-lg font-poppins font-semibold">
                  View Pricing
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
