import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from 'lucide-react';

// Load Stripe
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/payment-success`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your purchase!",
      });
    }
    setIsLoading(false);
  };

  return (
    <Card className="bg-dark-card silver-glow max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center metallic-text text-2xl">Complete Your Payment</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <PaymentElement />
          <Button 
            type="submit" 
            disabled={!stripe || isLoading}
            className="w-full bg-silver-gradient text-dark-base font-semibold py-3 hover:bg-opacity-90"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              'Pay Now'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

interface CheckoutProps {
  amount: number;
  serviceName: string;
}

export default function Checkout({ amount = 499, serviceName = "AI-Powered Website" }: CheckoutProps) {
  const [clientSecret, setClientSecret] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Create PaymentIntent as soon as the page loads
    fetch('/api/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else {
          toast({
            title: "Error",
            description: "Failed to initialize payment. Please try again.",
            variant: "destructive",
          });
        }
      })
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to initialize payment. Please try again.",
          variant: "destructive",
        });
      });
  }, [amount]);

  if (!clientSecret) {
    return (
      <div className="min-h-screen flex items-center justify-center section-bg">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-glow-blue border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-silver">Initializing secure payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen section-bg py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="font-poppins text-4xl font-bold mb-4 metallic-text">Secure Checkout</h1>
          <p className="text-xl text-silver-light">Service: {serviceName}</p>
          <p className="text-2xl font-bold text-glow-cyan">₹{amount}</p>
        </div>
        
        <Elements stripe={stripePromise} options={{ 
          clientSecret,
          appearance: {
            theme: 'night',
            variables: {
              colorPrimary: '#3b82f6',
              colorBackground: '#1e293b',
              colorText: '#e2e8f0',
              colorDanger: '#ef4444',
              fontFamily: 'Inter, sans-serif',
            }
          }
        }}>
          <CheckoutForm />
        </Elements>
      </div>
    </div>
  );
}