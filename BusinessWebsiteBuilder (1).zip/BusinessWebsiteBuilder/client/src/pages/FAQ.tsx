import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function FAQ() {
  const [openItems, setOpenItems] = useState<number[]>([0]); // First item open by default

  const toggleItem = (index: number) => {
    if (openItems.includes(index)) {
      setOpenItems(openItems.filter(item => item !== index));
    } else {
      setOpenItems([...openItems, index]);
    }
  };

  const faqs = [
    {
      question: "How fast is the delivery?",
      answer: "We deliver most projects within 24-48 hours. For complex projects like e-commerce stores or custom integrations, delivery may take 2-3 days. Our AI automation helps us work faster than traditional agencies."
    },
    {
      question: "What if I need updates after delivery?",
      answer: "We offer free minor updates for 30 days after delivery. For major changes or ongoing maintenance, we have affordable monthly packages starting from ₹199/month."
    },
    {
      question: "Do I need any technical knowledge?",
      answer: "Not at all! Our AI-powered process is designed for non-technical users. You just need to provide your business information, preferences, and content. We handle all the technical aspects."
    },
    {
      question: "Can I see my website before it goes live?",
      answer: "Yes! We provide a preview link where you can review your website before it goes live. You can request changes, and we'll implement them before the final launch."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major payment methods including UPI, bank transfers, credit/debit cards, and PayPal. Payment is typically 50% advance and 50% on delivery."
    },
    {
      question: "Do you provide hosting and domain?",
      answer: "Yes, we can arrange hosting and domain registration for you at competitive rates. Alternatively, you can provide your own hosting, and we'll deploy the website for you."
    },
    {
      question: "Is my website mobile-friendly?",
      answer: "Absolutely! All our websites are fully responsive and mobile-optimized. They work perfectly on desktops, tablets, and smartphones, ensuring a great user experience across all devices."
    },
    {
      question: "Can you help with digital marketing?",
      answer: "Yes! We offer digital marketing services including SEO optimization, social media setup, Google My Business optimization, and AI-powered content creation to help grow your online presence."
    },
    {
      question: "What makes WebSetu different from other web agencies?",
      answer: "Our AI-powered approach makes us faster and more affordable. We specialize in Indian businesses, understand local needs, and deliver professional results at a fraction of traditional costs."
    },
    {
      question: "Do you offer support after the project is completed?",
      answer: "Yes, we provide 30 days of free support after delivery. This includes minor updates, bug fixes, and technical assistance. We also offer ongoing support packages for long-term maintenance."
    }
  ];

  return (
    <section className="py-20 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-300">
            Get answers to common questions about our AI-powered services and process
          </p>
        </div>
        
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <Card key={index} className="bg-dark-card glow-border">
              <CardContent className="p-0">
                <Button
                  onClick={() => toggleItem(index)}
                  variant="ghost"
                  className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-transparent focus:outline-none"
                >
                  <span className="font-poppins text-lg font-semibold pr-4">
                    {faq.question}
                  </span>
                  {openItems.includes(index) ? (
                    <ChevronUp className="h-5 w-5 text-glow-blue flex-shrink-0" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-glow-blue flex-shrink-0" />
                  )}
                </Button>
                
                {openItems.includes(index) && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-300 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-16 text-center">
          <Card className="bg-dark-card glow-border">
            <CardContent className="p-8">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-glow-blue">Still Have Questions?</h3>
              <p className="text-gray-300 text-lg mb-6">
                Can't find the answer you're looking for? Our team is here to help you with any specific questions about your project.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-3 text-lg font-poppins font-semibold hover:scale-105 transform transition-all duration-300">
                  Contact Support
                </Button>
                <Button 
                  variant="outline" 
                  className="border-2 border-glow-blue px-8 py-3 text-lg font-poppins font-semibold hover:bg-glow-blue/10 transition-colors duration-300"
                >
                  Start Live Chat
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="mt-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-glow-blue mb-2">2-4 Hours</div>
              <p className="text-gray-300">Average Response Time</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-glow-cyan mb-2">500+</div>
              <p className="text-gray-300">Questions Answered</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-emerald-400 mb-2">99%</div>
              <p className="text-gray-300">Problem Resolution Rate</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
