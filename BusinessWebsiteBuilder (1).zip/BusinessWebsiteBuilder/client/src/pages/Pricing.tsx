import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { Link } from "wouter";

export default function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "₹499",
      description: "Perfect for individuals and small businesses",
      features: [
        "1 Website/Service",
        "Basic AI Features",
        "24-48 Hour Delivery",
        "Email Support",
        "Mobile Responsive",
        "Basic SEO Setup"
      ],
      buttonText: "Get This Plan",
      buttonVariant: "outline" as const,
      popular: false
    },
    {
      name: "Pro",
      price: "₹999",
      description: "Best for growing businesses",
      features: [
        "3 Websites/Services",
        "Advanced AI Features",
        "12-24 Hour Delivery",
        "Priority Support",
        "WhatsApp Bot Included",
        "SEO Optimization",
        "Social Media Integration",
        "Analytics Setup"
      ],
      buttonText: "Get This Plan",
      buttonVariant: "default" as const,
      popular: true
    },
    {
      name: "Agency",
      price: "₹1999",
      description: "For agencies and large businesses",
      features: [
        "Unlimited Projects",
        "Premium AI Features",
        "Same Day Delivery",
        "24/7 Support",
        "White Label Solutions",
        "Custom Integration",
        "Advanced Analytics",
        "Dedicated Account Manager",
        "API Access",
        "Custom Training"
      ],
      buttonText: "Get This Plan",
      buttonVariant: "secondary" as const,
      popular: false
    }
  ];

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Pricing Plans</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Choose the perfect plan for your business needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${
                plan.popular 
                  ? 'bg-dark-card border-2 border-glow-blue glow-border' 
                  : 'bg-dark-card border-2 border-gray-600 hover:border-glow-blue'
              } transition-all duration-300`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-glow-blue to-glow-cyan px-6 py-1 text-sm font-semibold">
                    Popular
                  </Badge>
                </div>
              )}
              
              <CardContent className="p-8 text-center">
                <h3 className="font-poppins text-2xl font-bold mb-4">{plan.name}</h3>
                <div className={`text-4xl font-bold mb-6 ${
                  plan.popular ? 'text-glow-cyan' : index === 2 ? 'text-emerald-400' : 'text-glow-blue'
                }`}>
                  {plan.price}
                </div>
                <p className="text-gray-300 mb-8">{plan.description}</p>
                
                <ul className="text-left space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="text-emerald-400 h-5 w-5 mr-3 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Link href="/contact">
                  <Button 
                    variant={plan.buttonVariant}
                    className={`w-full py-3 font-poppins font-semibold hover:scale-105 transform transition-all duration-300 ${
                      plan.popular 
                        ? 'bg-gradient-to-r from-glow-cyan to-glow-blue' 
                        : index === 2 
                          ? 'bg-gradient-to-r from-emerald-400 to-glow-cyan text-dark-base' 
                          : 'bg-gradient-to-r from-glow-blue to-glow-cyan'
                    }`}
                  >
                    {plan.buttonText}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20">
          <Card className="bg-dark-card glow-border max-w-4xl mx-auto">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-4 text-glow-blue">Enterprise Solutions</h3>
              <p className="text-gray-300 text-lg mb-6">
                Need a custom solution for your enterprise? We offer tailored packages with volume discounts, 
                dedicated support, and custom integrations for large organizations.
              </p>
              <Link href="/contact">
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-3 text-lg font-poppins font-semibold">
                  Contact Sales
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-glow-blue mb-2">30 Days</div>
              <p className="text-gray-300">Free Support & Updates</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-glow-cyan mb-2">100%</div>
              <p className="text-gray-300">Satisfaction Guarantee</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-emerald-400 mb-2">24-48h</div>
              <p className="text-gray-300">Average Delivery Time</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
