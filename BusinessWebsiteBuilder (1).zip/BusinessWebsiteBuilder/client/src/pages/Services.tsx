import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  Globe, 
  Video, 
  FileText, 
  Palette, 
  MessageCircle, 
  PenTool, 
  Play, 
  Ruler,
  Loader2
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Service } from "@shared/schema";

const getCategoryIcon = (category: string) => {
  switch (category.toLowerCase()) {
    case 'website': return Globe;
    case 'video': return Video;
    case 'design': return Palette;
    case 'ai-tools': return MessageCircle;
    case 'marketing': return PenTool;
    default: return Globe;
  }
};

const getCategoryColor = (category: string) => {
  switch (category.toLowerCase()) {
    case 'website': return "text-glow-blue";
    case 'video': return "text-glow-cyan";
    case 'design': return "text-purple-400";
    case 'ai-tools': return "text-green-400";
    case 'marketing': return "text-yellow-400";
    default: return "text-glow-blue";
  }
};

export default function Services() {
  const { data: services, isLoading, error } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  if (isLoading) {
    return (
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-glow-blue mx-auto" />
            <p className="text-gray-300 mt-4">Loading services...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error || !services) {
    return (
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-red-400">Failed to load services. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Our Services</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Comprehensive AI-powered digital solutions for modern businesses
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => {
            const IconComponent = getCategoryIcon(service.category);
            const color = getCategoryColor(service.category);
            return (
              <Card 
                key={service.id} 
                className="bg-dark-card glow-border hover:glow-border hover:scale-105 transform transition-all duration-300 group"
              >
                <CardContent className="p-6 text-center">
                  <IconComponent className={`h-12 w-12 ${color} mb-4 mx-auto group-hover:animate-float`} />
                  <h3 className="font-poppins text-xl font-semibold mb-3">{service.name}</h3>
                  <p className="text-gray-300 text-sm mb-4">{service.description}</p>
                  <div className="text-glow-cyan font-semibold mb-4">Starting ₹{service.basePrice}</div>
                  <Button 
                    variant="outline" 
                    className="w-full border-glow-blue hover:bg-glow-blue/10 transition-colors duration-300"
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-20">
          <Card className="bg-dark-card glow-border">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-6 text-glow-blue">Need Something Custom?</h3>
              <p className="text-gray-300 text-lg mb-8 max-w-3xl mx-auto">
                Don't see exactly what you need? Our AI-powered solutions can be customized for your specific business requirements. 
                Let's discuss your project and create something amazing together.
              </p>
              <Link href="/contact">
                <Button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-4 text-lg font-poppins font-semibold hover:scale-105 transform transition-all duration-300">
                  Get Custom Quote
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
