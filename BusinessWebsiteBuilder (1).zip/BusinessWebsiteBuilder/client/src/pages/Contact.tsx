import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, MessageCircle, Clock, MapPin, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertContactSchema, type InsertContact } from "@shared/schema";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await fetch('/api/contacts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to send message');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thank you for contacting us. We'll get back to you within 2-4 hours.",
      });
      setFormData({ name: "", email: "", message: "" });
      queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validatedData = insertContactSchema.parse(formData);
      contactMutation.mutate(validatedData);
    } catch (error) {
      toast({
        title: "Validation Error",
        description: "Please check your input and try again.",
        variant: "destructive",
      });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section className="section-bg py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">Get In Touch</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Ready to transform your business? Let's discuss your project and bring your vision to life.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div>
            <Card className="bg-dark-card glow-border">
              <CardContent className="p-8">
                <h3 className="font-poppins text-2xl font-bold mb-6 text-glow-cyan">Send us a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="text-sm font-medium mb-2 block">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      className="bg-dark-base border-gray-600 focus:border-glow-blue text-white"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-sm font-medium mb-2 block">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Enter your email"
                      className="bg-dark-base border-gray-600 focus:border-glow-blue text-white"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="message" className="text-sm font-medium mb-2 block">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      placeholder="Tell us about your project..."
                      className="bg-dark-base border-gray-600 focus:border-glow-blue text-white resize-none"
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit"
                    className="w-full bg-gradient-to-r from-glow-blue to-glow-cyan py-3 font-poppins font-semibold hover:scale-105 transform transition-all duration-300"
                    disabled={contactMutation.isPending}
                  >
                    {contactMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      "Send Message"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
          
          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="bg-dark-card glow-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <Mail className="h-8 w-8 text-glow-blue flex-shrink-0" />
                  <div>
                    <h4 className="font-poppins text-lg font-semibold">Email Us</h4>
                    <p className="text-gray-300">support@websetu.in</p>
                    <p className="text-sm text-gray-400">We respond within 2-4 hours</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-dark-card glow-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <MessageCircle className="h-8 w-8 text-green-400 flex-shrink-0" />
                  <div className="flex-1">
                    <h4 className="font-poppins text-lg font-semibold">WhatsApp / Phone</h4>
                    <p className="text-gray-300 mb-2">+91-6307737501</p>
                    <a href="tel:+916307737501">
                      <Button className="bg-green-500 hover:bg-green-600 font-semibold transition-colors duration-300 mr-2">
                        Call Now
                      </Button>
                    </a>
                    <a href="https://wa.me/916307737501" target="_blank" rel="noopener noreferrer">
                      <Button className="bg-green-600 hover:bg-green-700 font-semibold transition-colors duration-300">
                        WhatsApp
                      </Button>
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-dark-card glow-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <Clock className="h-8 w-8 text-glow-cyan flex-shrink-0" />
                  <div>
                    <h4 className="font-poppins text-lg font-semibold">Response Time</h4>
                    <p className="text-gray-300">Within 2-4 hours</p>
                    <p className="text-sm text-gray-400">Monday to Saturday, 9 AM - 8 PM</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-dark-card glow-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <MapPin className="h-8 w-8 text-purple-400 flex-shrink-0" />
                  <div>
                    <h4 className="font-poppins text-lg font-semibold">Location</h4>
                    <p className="text-gray-300">Mumbai, India</p>
                    <p className="text-sm text-gray-400">Serving clients across India</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <Card className="bg-dark-card glow-border max-w-4xl mx-auto">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-6 text-glow-blue">Quick Answers</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                <div>
                  <h4 className="font-semibold text-glow-cyan mb-2">How quickly can you start?</h4>
                  <p className="text-gray-300 text-sm">We can start your project within 24 hours of confirmation and payment.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-glow-cyan mb-2">What do you need from me?</h4>
                  <p className="text-gray-300 text-sm">Just your business info, preferences, and any content you want to include.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-glow-cyan mb-2">Do you offer revisions?</h4>
                  <p className="text-gray-300 text-sm">Yes! We include revisions and 30 days of free support with every project.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-glow-cyan mb-2">What about hosting?</h4>
                  <p className="text-gray-300 text-sm">We can arrange hosting or work with your existing hosting provider.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
