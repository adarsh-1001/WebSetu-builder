import { Card, CardContent } from "@/components/ui/card";
import { Star, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Testimonial } from "@shared/schema";

export default function Testimonials() {
  const { data: testimonials, isLoading, error } = useQuery<Testimonial[]>({
    queryKey: ['/api/testimonials'],
  });

  if (isLoading) {
    return (
      <section className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-glow-blue mx-auto" />
            <p className="text-gray-300 mt-4">Loading testimonials...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error || !testimonials) {
    return (
      <section className="section-bg py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-red-400">Failed to load testimonials. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="section-bg py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="font-poppins text-4xl md:text-5xl font-bold mb-6 text-glow-blue">What Our Clients Say</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Real feedback from satisfied customers who transformed their businesses with WebSetu
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card 
              key={testimonial.id} 
              className="bg-dark-card glow-border hover:glow-border transition-all duration-300 group"
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <img 
                    src={testimonial.imageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                    alt={`${testimonial.clientName} testimonial`}
                    className="w-12 h-12 rounded-full object-cover mr-4" 
                  />
                  <div>
                    <h4 className="font-poppins font-semibold">{testimonial.clientName}</h4>
                    <p className="text-glow-cyan text-sm">{testimonial.clientRole}</p>
                  </div>
                </div>
                
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, starIndex) => (
                    <Star key={starIndex} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                <p className="text-gray-300 italic leading-relaxed">"{testimonial.content}"</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20">
          <Card className="bg-dark-card glow-border max-w-4xl mx-auto">
            <CardContent className="p-8 text-center">
              <h3 className="font-poppins text-2xl font-bold mb-6 text-glow-blue">Join Our Success Stories</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-glow-blue mb-2">500+</div>
                  <p className="text-gray-300">Happy Clients</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-glow-cyan mb-2">1000+</div>
                  <p className="text-gray-300">Projects Completed</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-emerald-400 mb-2">99%</div>
                  <p className="text-gray-300">Client Satisfaction</p>
                </div>
              </div>
              <p className="text-gray-300 text-lg mb-6">
                Ready to become our next success story? Let's build something amazing together.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-gradient-to-r from-glow-blue to-glow-cyan px-8 py-3 rounded-lg font-poppins font-semibold hover:scale-105 transform transition-all duration-300">
                  Start Your Project
                </button>
                <button className="border-2 border-glow-blue px-8 py-3 rounded-lg font-poppins font-semibold hover:bg-glow-blue/10 transition-colors duration-300">
                  View Portfolio
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
