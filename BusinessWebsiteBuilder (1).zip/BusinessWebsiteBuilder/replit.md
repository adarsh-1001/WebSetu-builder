# WebSetu - AI-Powered Website Builder

## Overview

WebSetu is a modern full-stack web application that helps individuals and small Indian businesses create professional websites using AI technology. The platform offers various digital services including website creation, AI video editing, resume building, design services, and WhatsApp bot integration at affordable prices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack React Query for server state
- **Build Tool**: Vite for development and bundling
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured via Neon serverless)
- **Session Storage**: Connect-pg-simple for PostgreSQL session store
- **Development**: Hot module replacement with Vite integration

### Design System
- **Theme**: Dark mode with custom CSS variables
- **Typography**: Poppins and Inter font families
- **Color Scheme**: Blue/cyan glow theme with neutral base
- **Animations**: Custom CSS animations and transitions
- **Components**: Consistent component library using shadcn/ui

## Key Components

### Pages Structure
The application consists of 9 main pages:
1. **Home**: Hero section with AI-powered website promotion
2. **About**: Company mission and founder information
3. **Services**: Service offerings with pricing
4. **Portfolio**: Showcase of completed projects
5. **Pricing**: Three-tier pricing plans (Starter, Pro, Agency)
6. **Testimonials**: Customer reviews and ratings
7. **Blog**: Content marketing articles
8. **Contact**: Contact form and business information
9. **FAQ**: Frequently asked questions

### Core Features
- **AI Chatbot**: Floating robotic assistant for customer support
- **Particle Background**: Animated canvas-based background effects
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Interactive Elements**: Hover effects, animations, and transitions
- **Form Handling**: Contact forms with validation
- **SEO Optimization**: Structured content for search engines

## Data Flow

### Database Schema
- **Users Table**: Basic user authentication structure
- **Schema Location**: `/shared/schema.ts`
- **Validation**: Zod schemas for type-safe data validation

### API Structure
- **Routes**: Express.js routes in `/server/routes.ts`
- **Storage Interface**: Abstracted storage layer with in-memory implementation
- **Error Handling**: Centralized error handling middleware
- **Logging**: Request/response logging for API endpoints

### State Management
- **Client State**: React hooks and local state
- **Server State**: TanStack React Query for API data fetching
- **Form State**: React Hook Form with Zod validation

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Class Variance Authority**: Type-safe component variants

### Development Tools
- **TypeScript**: Type safety across the stack
- **ESBuild**: Fast bundling for production
- **TSX**: TypeScript execution for development
- **Drizzle Kit**: Database schema management

### Database and Backend
- **Neon Database**: Serverless PostgreSQL
- **Connect-pg-simple**: PostgreSQL session store
- **Express.js**: Web application framework

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized client-side bundle
- **Backend**: ESBuild creates production server bundle
- **Assets**: Static files served from `/dist/public`

### Environment Configuration
- **Development**: Hot reload with Vite dev server integration
- **Production**: Express serves static files and API routes
- **Database**: Environment-based DATABASE_URL configuration

### File Structure
```
├── client/          # Frontend React application
├── server/          # Backend Express server
├── shared/          # Shared types and schemas
├── dist/            # Production build output
├── migrations/      # Database migration files
└── attached_assets/ # Static assets and requirements
```

The architecture prioritizes rapid development, type safety, and modern web standards while maintaining a clean separation between frontend and backend concerns. The use of shared TypeScript types ensures consistency across the full stack.