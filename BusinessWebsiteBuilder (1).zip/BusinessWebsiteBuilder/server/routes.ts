import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { 
  insertContactSchema,
  insertSubscriptionSchema,
  insertPortfolioItemSchema,
  insertTestimonialSchema,
  insertServiceSchema,
  insertProjectSchema 
} from "@shared/schema";

// Import Stripe
import Stripe from "stripe";
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Stripe payment route for one-time payments
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe not configured" });
    }

    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "inr", // Indian Rupees
        metadata: {
          company: "WebSetu",
          service: "AI-Powered Website Creation"
        }
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });
  // Contact form submission
  app.post("/api/contacts", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.json({ success: true, contact });
    } catch (error) {
      res.status(400).json({ error: "Invalid contact data" });
    }
  });

  // Get all contacts (admin only)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  // Newsletter subscription
  app.post("/api/subscriptions", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      const subscription = await storage.createSubscription({ email });
      res.json({ success: true, subscription });
    } catch (error) {
      res.status(400).json({ error: "Failed to subscribe" });
    }
  });

  // Unsubscribe from newsletter
  app.delete("/api/subscriptions/:email", async (req, res) => {
    try {
      const { email } = req.params;
      const success = await storage.unsubscribe(email);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: "Failed to unsubscribe" });
    }
  });

  // Get active portfolio items
  app.get("/api/portfolio", async (req, res) => {
    try {
      const items = await storage.getActivePortfolioItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch portfolio items" });
    }
  });

  // Create portfolio item (admin only)
  app.post("/api/portfolio", async (req, res) => {
    try {
      const itemData = insertPortfolioItemSchema.parse(req.body);
      const item = await storage.createPortfolioItem(itemData);
      res.json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid portfolio item data" });
    }
  });

  // Get active testimonials
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch testimonials" });
    }
  });

  // Create testimonial (admin only)
  app.post("/api/testimonials", async (req, res) => {
    try {
      const testimonialData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(testimonialData);
      res.json(testimonial);
    } catch (error) {
      res.status(400).json({ error: "Invalid testimonial data" });
    }
  });

  // Get active services
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getActiveServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Create service (admin only)
  app.post("/api/services", async (req, res) => {
    try {
      const serviceData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(serviceData);
      res.json(service);
    } catch (error) {
      res.status(400).json({ error: "Invalid service data" });
    }
  });

  // Create project/order
  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      res.status(400).json({ error: "Invalid project data" });
    }
  });

  // Get user projects
  app.get("/api/users/:userId/projects", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user projects" });
    }
  });

  // Update project status
  app.patch("/api/projects/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const project = await storage.updateProjectStatus(id, status);
      res.json(project);
    } catch (error) {
      res.status(400).json({ error: "Failed to update project status" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'user_message') {
          // Simple AI response simulation
          setTimeout(() => {
            const aiResponses = {
              pricing: "Our services start from ₹499 for AI-powered websites. We offer Website Creation (₹499), AI Video Editing (₹299), Resume Builder (₹199), and WhatsApp Bot (₹399).",
              website: "We create professional, responsive websites using AI technology. The process takes 24-48 hours and includes hosting, SSL, and mobile optimization.",
              services: "WebSetu offers 4 main services: 🌐 Website Creation, 🎥 AI Video Editing, 📄 Resume Builder, and 💬 WhatsApp Bot integration. All powered by AI!",
              payment: "We accept secure payments via Stripe (cards, UPI, net banking). All transactions are encrypted. You'll receive confirmation after payment.",
              contact: "You can reach us at +91-6307737501 or connect with Adarsh on LinkedIn. We respond within 2-4 hours during business hours.",
              default: "I'd be happy to help! You can ask me about our services, pricing, website creation process, or any other questions about WebSetu."
            };

            const userMessage = message.message.toLowerCase();
            let response = aiResponses.default;

            if (userMessage.includes('price') || userMessage.includes('cost') || userMessage.includes('₹')) {
              response = aiResponses.pricing;
            } else if (userMessage.includes('website') || userMessage.includes('site')) {
              response = aiResponses.website;
            } else if (userMessage.includes('service')) {
              response = aiResponses.services;
            } else if (userMessage.includes('payment') || userMessage.includes('pay')) {
              response = aiResponses.payment;
            } else if (userMessage.includes('contact') || userMessage.includes('phone')) {
              response = aiResponses.contact;
            }

            ws.send(JSON.stringify({
              type: 'ai_response',
              message: response
            }));
          }, 1000 + Math.random() * 1500); // Random delay to simulate thinking
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });

    // Send welcome message
    ws.send(JSON.stringify({
      type: 'ai_response',
      message: 'Hello! I\'m your AI assistant. How can I help you with WebSetu services today?'
    }));
  });

  return httpServer;
}
